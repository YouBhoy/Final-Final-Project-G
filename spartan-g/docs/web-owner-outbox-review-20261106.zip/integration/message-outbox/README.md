# Sprint 4 web-owner outbox review package

November 6, 2026. Local source review and synthetic emulator evidence only. **No deployment, Main modification/merge, notification activation or APK work is authorized by this package.**

## Correct Main source

`MAIN_WEB_OWNER.patch` is pinned to Main commit `3245e97926a5a38fdd2e080cb5488da3a5745f73`. It supersedes the Sprint 2 patch based on `7e671a3`; do not apply that older patch to current Main. Main was inspected by read-only Git operations; its commit object was retrieved without updating branch references or FETCH_HEAD.

The patch adds only the shared helper import, deterministic outbox reference allocated beside the message ID, and one `transaction.set` in the existing transaction. It adds the same helper file as App. **It does not replace Main's service with App's service.** Removing exactly these additions restores the Main source byte-for-byte.

Preserved unchanged: the optional sixth `identityRecipientId` argument, student-role/sole-other-participant validation, `student_identity_consents/{facilitatorId}_{studentId}` write inside the transaction, message schema, conversation/unread updates, and existing best-effort in-app notifications. The original confirmation hook and MessageThread snapshots document Main's existing cancel/confirm, account/conversation scope and pre-send confirmation gate. They are evidence, not replacement web files.

Consent remains an explicit existing identity-disclosure operation. The outbox is not consent. Main's ordinary service messages without that optional parameter do not invent consent; the current web caller still confirms student disclosure and supplies its actual participant. Rules retain the existing student owner, active facilitator target, exact consent fields and server timestamp checks. No UI or authentication rule was removed.

## Exact contract

The canonical message fields remain `conversationId`, `senderId`, `body`, `attachmentUrl`, `readBy`, `createdAt`, `updatedAt`. Conversation IDs, message order, last-message metadata and unread counts are unchanged.

The only new collection is `notification_outbox`, with deterministic document ID `message_<messageId>` and these six fields:

```ts
{
  schemaVersion: 1,
  kind: 'message.created',
  messageId,
  conversationId,
  senderId,
  createdAt: serverTimestamp()
}
```

There is **no recipient field**, body, attachment URL, token, consent field or privileged processing state. Recipients are derived from the canonical conversation and reauthorized by the trusted notification core. Main's identity-consent record remains separate, in the same commit. No existing record is migrated or backfilled.

SDK transaction callback retries reuse the message and event IDs. A rejected message, outbox, consent or conversation update rolls back the full transaction. No message-only fallback or application resend is introduced. A lost commit response may leave one committed pair despite a returned error; deliberate later resends with new IDs are separate messages, not semantically deduplicated.

## Complete Rules candidates

Every `.rules` file is a complete configuration with its immutable baseline, exact `.diff` and SHA-256 in `MANIFEST.json`. No root Firebase configuration or checked-in Rules was edited. No live Firebase Rules was retrieved in Sprint 4.

| Candidate | Intended review | Legacy writers | Consent |
| --- | --- | --- | --- |
| `MAIN_TRANSITION.rules` | **Recommended Main integration candidate**, based on the pinned current Main source Rules | Accepted; no outbox guaranteed | Existing Main consent preserved |
| `MAIN_STRICT.rules` | Future enforcement only, **not rollout-ready** | Rejected | Existing Main consent preserved |
| `SAVED_PRODUCTION_TRANSITION.rules` | Compatibility evidence against the saved Garden-fixed production snapshot | Accepted | Preserved |
| `SAVED_STAGING_TRANSITION.rules` | Compatibility evidence against the saved staging snapshot | Accepted | Preserved |
| `CHECKED_IN_TRANSITION.rules` | Evidence against App's old checked-in template; **not a Main/production replacement** | Accepted | Old template has no consent permission |

All candidates validate exact event fields, active authenticated sender, same canonical conversation/message, server commit timestamps and pre-write message absence. Only a corresponding **new** valid message may create an event. Forged recipients, arbitrary kinds/IDs, sender spoofing, historical-message backfill and orphan events are denied. Clients, including an admin-role client, cannot read/list/update/delete outboxes. Server IAM remains a separate trusted boundary.

The transition candidates preserve valid message-only creation. Strict Main additionally requires the matching event for every message creation. The old App template's message-create allowance lacked canonical membership/body/timestamp checks; its compatibility candidate adds those required message checks but preserves unrelated Rules. Its unrelated conversation/profile/consent policies remain older and are **not approved for shared production use**. Do not overwrite current Main's identity/privacy Rules with that file.

`MAIN_TRANSITION.rules` SHA-256: `c230900b5ee761079ec99a01da1fc62e22fbde9f484940ec9700af8dcc7f3038`.

`MAIN_STRICT.rules` SHA-256: `3080f4de4a46805a5471f4ea7ab5108ae5bb098a1a010f768fb3a10c8b36ea70`.

## Owner integration and reproducible checks

The patch was checked and applied only in an isolated temporary copy; resulting bytes matched the tested Main candidate/helper. It was not applied to Main or the active App writer. In the owner's own checkout, verify the Main commit and base-file checksum first. Intervening changes require a fresh minimal review; never force an old patch or merge App wholesale.

The proposed **separately approved** owner commands are:

```powershell
git apply --check <reviewed-path-to-MAIN_WEB_OWNER.patch>
git apply <reviewed-path-to-MAIN_WEB_OWNER.patch>
```

Patch paths are relative to the Git top-level and include the `spartan-g/` prefix. These commands have not been executed on Main. The owner must run the full Main web TypeScript/build, consent, messaging and in-app notification checks. The App workspace check covered the isolated Main writer with 76 Git-pinned Main dependency files, not a full web build.

The new source tests live in `packages/shared-services/tests/message-outbox*.cjs` and `run-message-outbox-emulator.cjs`. They require Node 22, existing workspace/Functions dependencies, a Java runtime and the Firestore emulator JAR. They do not install dependencies or download the emulator. Run them in the **App source checkout** containing the prepared backend, using the packaged Main snapshots; do not copy all App services into Main to satisfy tests.

```powershell
node --require ./packages/shared-services/tests/message-outbox-no-egress.cjs --test packages/shared-services/tests/message-outbox.test.cjs packages/shared-services/tests/message-outbox-consent.test.cjs
node packages/shared-services/tests/run-message-outbox-emulator.cjs MAIN_TRANSITION
node packages/shared-services/tests/run-message-outbox-emulator.cjs MAIN_STRICT
```

The runner also accepts saved/current candidate and baseline labels from the manifest, plus `_LEGACY` for the focused original-Main-consent check. It refuses to overwrite an existing run directory or use an occupied emulator port. For a repeated local test use the documented `_VERIFIED`/`_FINAL` suffix or preserve/move your own evidence separately; no output is automatically deleted. Optional `FIRESTORE_EMULATOR_JAR` and `OUTBOX_TEST_JAVA` select local tools, not cloud credentials. The JAR SHA-256 is pinned to `9b6498b7f62714d67f48f59b3818883cd682dbcd46b9f59511de81c97bb5166c`.

Tests bind only loopback port 18082 under `demo-push-stage1`, clear credential variables and block non-emulator socket connections. Administrative emulator access only seeds/inspects synthetic records. Notification sends are in-memory observers; no FCM request or real device registration exists in these tests. Hook tests use a local React-hook harness, not a browser/phone UI run.

## Rollout and rollback dependencies

1. Owner reviews the current-Main patch, complete transition candidate and evidence; performs separately approved local integration/full web checks.
2. Before any live change, obtain a separately authorized fresh deployed-Rules baseline/version/backup. Compare it with the saved/current-source baselines and preserve every intervening identity/privacy change. A source candidate is not proof of current cloud content. Re-review/retest if the baseline differs.
3. Approve a coordinated synthetic staging cohort, its staging-specific compatible Rules, pinned client/backend identity and disabled backend configuration. Publish compatible **transition Rules before using updated writers**. An updated writer against old Rules fails atomically. Do not publish a production Rules snapshot to staging simply because it passed a local test.
4. Release updated web/mobile writers only through their separate release approvals. Old v31 APKs and unchanged web writers must remain functional under transition Rules. Their messages lack outbox events, so automatic capture for those messages is not promised. Do not fabricate/backfill events or claim snapshot polling is lossless.
5. Backend deployment, credentials/IAM, registration and a bounded synthetic push pilot require separate approval. Keep the existing 30-minute controls, budgets, single-attempt transport and unknown-outcome retention. Production delivery stays disabled. FCM acceptance is not device-display proof.
6. Strict Rules remain deferred while any relevant legacy writer is active. Universal capture plus indefinite legacy writing requires a separately approved trusted writer/trigger design; an arbitrary client version string is not enforcement.

For rollback, stop the approved backend control first. If strict Rules were activated later, restore compatible transition Rules under separate approval **before** rolling a writer back. Keep outbox permission while modern clients remain and legacy message permission while old clients remain. Do not delete saved messages, app data, consent, outboxes, queues, claims, budgets or ambiguous attempts. A mobile rollback normally needs a forward compatible release using the same package/signature, not uninstall/data deletion. Reverse only the reviewed writer additions in an owner-controlled checkout after checking unrelated changes; never reset/replace Main.

**GO for web-owner review/approval of the pinned Main patch plus Main transition candidate. NO-GO for Rules deployment or automatic notifications.** The minimum next authorization is owner-controlled local Main integration and full web validation, followed by a fresh read-only deployed-Rules comparison and a coordinated staging rollout plan. No cloud publication is implied.
