# Sprint 4 — web-owner outbox review findings

November 6, 2026, Asia/Manila. **All three findings are addressed and tested locally for the pinned Main integration package. GO for web-owner review/approval; NO-GO for Rules deployment or automatic notifications.** No existing application source, checked-in Rules or Main file was edited.

## 1. Rules compatibility

The actual checked-in deployment target is `firebase/firestore.rules`, selected by `firebase.json`. Its SHA-256 is `96cfa24d2b7e049347e5589bf93af9c56ca315a9dea9d0a5836de5ff7f8d7ed4`. It has no `notification_outbox` allowance and no identity-consent match. Its older message-create condition checks sender activity/identity but lacks current Main's canonical membership/body/timestamp conditions. Current Main source Rules and both saved cloud snapshots also lack an outbox allowance. The fresh baseline emulator checks prove legacy writers work and paired writes fail completely under these unchanged configurations.

Prepared five **complete** candidate files with immutable baselines, exact diffs and checksums under `integration/message-outbox/`:

| Candidate | SHA-256 | Finding |
| --- | --- | --- |
| CHECKED_IN_TRANSITION.rules | `b256619b64e88342a03bf52a227161ac713c07e4bd47890abd99f05cc30cf803` | Android compatibility evidence only; **not a Main/production replacement** |
| MAIN_TRANSITION.rules | `c230900b5ee761079ec99a01da1fc62e22fbde9f484940ec9700af8dcc7f3038` | Updated and legacy writers accepted; existing consent preserved |
| MAIN_STRICT.rules | `3080f4de4a46805a5471f4ea7ab5108ae5bb098a1a010f768fb3a10c8b36ea70` | Future enforcement; rejects legacy writers |
| SAVED_PRODUCTION_TRANSITION.rules | `af6c8844c543233d766454647e33514003fc1d94ec815d749ae98b59224bc965` | Updated and legacy writers accepted; existing consent preserved |
| SAVED_STAGING_TRANSITION.rules | `f70b2855b7dd77552045873cf4259aeb51e9a9a4f1d65c1c521083005e849fc7` | Updated and legacy writers accepted; existing consent preserved |

**Use Main transition as the owner integration review target.** The old checked-in-template candidate intentionally does not invent Main's missing identity/privacy policies or replace unrelated permissions. Its message-create checks are narrowed to valid canonical messages, but its unrelated conversation/profile policies remain older. It is not a shared-production deployment recommendation. Saved production/staging files are historical snapshots, not verified live Rules. No Firebase cloud request was made.

Each outbox requires exact six-field metadata, active authenticated sender, matching canonical conversation/message, a new message absent before the commit, valid body and common server timestamps. Forged recipient/processing/content fields, sender spoofing, cross-conversation mismatches, orphan events and historical-message backfill are rejected. Client reads/listing/updates/deletes are denied, including admin-role client accounts. Main's existing relationship-based conversation creation and immutable membership remain intact and have additional negative tests. Consent matches are byte-identical to each supporting baseline.

Transition does not require an event from old writers; strict Main does. This preserves v31 and unchanged web messaging while admitting their capture gap. No strict Rules was published, and no current root Rules/configuration was changed.

## 2. Current Main and identity consent

Main was verified at remote commit `3245e97926a5a38fdd2e080cb5488da3a5745f73`; local Main remains untouched at its existing reference. The old Sprint 2 patch targeted `7e671a3` and must not be treated as the current handoff. The new `MAIN_WEB_OWNER.patch` adds only a helper import, pre-callback outbox reference and atomic event write, plus the helper file. Patch SHA-256: `c6426c92be3c8c8d84864557ba3c5c98c50395ea039a104e2bdda96d80363716`.

The optional sixth `identityRecipientId` parameter, student/sole-recipient checks, consent record write, message/conversation/unread handling and best-effort in-app behavior are preserved exactly. Removing the three additions restores the pinned Main file byte-for-byte. The patch passed `git apply --check` and actual application in an isolated temporary copy, followed by byte comparison. No patch was applied to Main or the active App writer.

The current Main confirmation hook and MessageThread caller were inspected and saved as public source evidence. Tests cover cancel versus approval, acknowledgement scope, account/conversation switching, stale approval, unmount, facilitator behavior and awaiting confirmation before sending. Main's optional identity disclosure remains distinct from generic message/outbox authorization. Existing in-app previews are preserved; private content is absent from outbox and prepared phone payloads.

## 3. Meaningful source tests and results

The new tests are ordinary source files in `packages/shared-services/tests/`, not only uncommitted historical logs. They execute the actual App writer and the pinned current Main candidate/base. The legacy Android fixture is hash-bound to the protected v31 writer. Hook tests execute current Main's hook in a local React-hook harness; they are not browser/device runtime verification.

| Final selected configuration | Passed |
| --- | ---: |
| Writer, contract, failure/retry, consent UI/core and source preservation unit checks | 33 |
| MAIN_TRANSITION_VERIFIED | 30 |
| MAIN_STRICT | 30 |
| SAVED_PRODUCTION_TRANSITION | 30 |
| SAVED_STAGING_TRANSITION | 30 |
| CHECKED_IN_TRANSITION | 25 |
| MAIN_BASE | 5 |
| CHECKED_IN_BASE | 4 |
| MAIN_TRANSITION_LEGACY | 2 |
| MAIN_STRICT_LEGACY | 2 |
| **Total selected passing checks** | **191** |

**Zero final failures.** Actual mobile source graph: zero TypeScript diagnostics. Pinned Main writer with 76 Main dependency source overlays: zero diagnostics, no emit. This is not a full Main web build; that remains owner work. The prior historical risk-alert mock failures are unchanged and were not relabeled as passing or included in this total.

Coverage includes exact event/message fields and canonical recipient targeting, stable IDs through callback retries, concurrent sends/unread updates, duplicate IDs, rollback on message/outbox/consent/conversation rejection, lost commit response without application resend, stale accounts, unauthorized roles/recipients, permission-denied reads, history order/read receipts, and real notification-core authorization/deduplication with an in-memory sender. No FCM transport call occurred. The original Main consent writer also passes transition Rules without an event; strict Rules reject it without leaving consent or a message behind.

All Firestore activity was synthetic under `demo-push-stage1`, loopback 18082, with non-emulator socket connections blocked and credentials cleared. The emulator JAR hash was pinned and every owned emulator/test process stopped. Initial test-fixture syntax/import defects were corrected; failed evidence was retained. A generator replacement-string issue was caught by the unchanged-text guard before a candidate was accepted, corrected locally and round-trip verified. No application safeguard or test expectation was relaxed to pass.

## Exact contract, rollout and rollback

`integration/message-outbox/README.md` contains the exact six-field contract, candidate matrix, owner patch procedure, reproducible test commands, rollout order and rollback. Existing canonical message fields/ordering are unchanged. There is no new client-selected recipient or consent field. Recipients come from current canonical records and are reauthorized before a prepared send; mocks are not evidence of device delivery.

Minimum safe order: owner local integration and full web checks; separately approved fresh deployed-Rules version/content backup and comparison; target-specific transition candidate review/testing; compatible transition Rules before any updated writer release; coordinated synthetic staging client/backend pilot under existing limits. Do not overwrite live identity/privacy changes with a saved snapshot. Keep transition while old APK/web writers remain; their missing events are disclosed. Strict enforcement must wait for all relevant writers to be updated/verified or a separately approved trusted-write alternative.

If rollback becomes necessary after a later authorized rollout, stop the approved backend control. Restore transition compatibility before rolling back a writer from strict mode. Keep event permission while updated clients exist and old message permission while old clients remain. Preserve messages, consent, APK/app data, outboxes, queues, claims, budgets and ambiguous attempts. Do not uninstall clients, delete evidence or reset unknown delivery claims. No rollback or deployment occurred here.

## Changed-file inventory and preservation

**All Sprint 4 outputs are new files**: the `integration/message-outbox/` review package, eight new source test/runner files under `packages/shared-services/tests/`, and the local `docs/message-outbox-sprint4-20261106/` evidence/scripts/report. `FILES.json` enumerates every new path, size and checksum. Existing App writer/helper, old tests, backend sources, root Rules, package/lockfiles, native configuration and all unrelated working-tree changes remain unchanged. Nothing was staged or committed.

`PRESERVATION.json` verifies **2118 existing paths**, all **46 APK hashes/inventory**, external signing metadata, protected manifest, original Git references (including before the read-only Main object retrieval), branch/HEAD, Main and remote App/Main pins. Private signing contents were not read. The protected 384-input manifest remains `42f53390e687cdee469e9b31d719627499ea339cdc7a4f50092428612687ec87`, with no refresh. Production Firebase/data, Garden/Forest, Dashboard/flag/mascot, More, Sparty, Settings/privacy, authentication and messaging sources were preserved.

## Decision and next authorization

**GO:** web-owner review/approval of the pinned minimal Main patch, Main transition candidate and 191-check evidence. **NO-GO:** Rules deployment, strict rollout or automatic notification activation. A published App source commit alone does not resolve the live Rules prerequisite.

**Exact next authorization:** owner-controlled local application/review of the pinned Main patch and full web validation, then a fresh read-only deployed-Rules version/content comparison and target-specific staging compatibility preflight. Do not merge/replace Main. Cloud Rules publication, backend/credential setup, notification pilot and APK preparation/builds remain separate explicit approvals. This task performs none of them.
