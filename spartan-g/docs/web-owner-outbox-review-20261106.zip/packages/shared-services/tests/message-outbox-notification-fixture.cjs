'use strict';
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const{root,evaluate}=require('./message-outbox-fixture.cjs');
const load=(p,imports={})=>evaluate(fs.readFileSync(path.join(root,p),'utf8'),imports);
function notificationFixture(){
 const rows=new Map(),sent=[],proofs=[];let tail=Promise.resolve(),serial=0;
 const store={get:async p=>structuredClone(rows.get(p)??null),bindings:async uid=>[...rows].filter(([p,r])=>p.startsWith('notification_devices/')&&r.uid===uid).map(([,r])=>structuredClone(r)),transaction(fn){const run=tail.then(async()=>{let wrote=false;const pending=[];const result=await fn({get:async p=>{assert.equal(wrote,false);return structuredClone(rows.get(p)??null);},set:(p,r)=>{wrote=true;pending.push([p,structuredClone(r)]);}});for(const[p,r]of pending)rows.set(p,r);return result;});tail=run.catch(()=>{});return run;}};
 const contract=load('packages/shared-services/src/notifications/push-contract.ts');
 const shared={'../../packages/shared-services/src/notifications/push-contract':contract};
 const support=load('services/student-support/support-runtime.ts',shared);
 const server=load('services/student-support/notification-runtime.ts',{'node:crypto':crypto,'./support-runtime':support,...shared});
 const runtime=server.createNotificationBackend({enabled:true,project:'spartan-g-assessment-staging',database:'(default)',store,now:Date.now,random:()=>('synthetic_sprint4_nonce_'+ ++serial).padEnd(48,'x'),verifyStudent:async token=>{const uid=token.match(/^synthetic\.jwt\.([A-Za-z_]+)\.123456789$/)?.[1];if(!uid)throw Error('Denied');return{uid,role:rows.get('users/'+uid)?.role};},accountActive:async uid=>rows.get('users/'+uid)?.isActive===true,consume:async()=>true,permitSend:async()=>true,challenge:async(token,proof,authorize)=>{assert.equal(await authorize(),true);proofs.push({token,...proof});},send:async(message,authorize)=>{assert.equal(await authorize(),true);sent.push(message);}});
 const preferences={phoneEnabled:true,messages:true,appointments:true,assessmentUpdates:true};
 async function bind(uid){const invoke=(operation,body)=>runtime.handle({method:'POST',path:operation,authorization:'Bearer synthetic.jwt.'+uid+'.123456789',body});const begin=await invoke('begin',{token:'synthetic_native_token_for_'+uid+'_12345678901234567890',installationId:'synthetic_installation_'+uid,preferences,revocationKey:('synthetic_revoke_'+uid).padEnd(48,'x')});assert.equal(begin.status,200);const complete=await invoke('complete',{challengeId:begin.body.challengeId,proof:proofs.at(-1).proof});assert.equal(complete.status,200);return complete.body.id;}
 return{rows,sent,store,runtime,bind};
}
module.exports={notificationFixture,load};
