'use strict';
const{test,after}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const{root,loadWriter}=require('./message-outbox-fixture.cjs');
const sdk=require(path.join(root,'node_modules/firebase/firestore')),apps=require(path.join(root,'node_modules/firebase/app'));
const aa=require(require.resolve('firebase-admin/app',{paths:[path.join(root,'functions')]})),admin=require(require.resolve('firebase-admin/firestore',{paths:[path.join(root,'functions')]}));
assert.equal(process.env.GCLOUD_PROJECT,'demo-push-stage1');assert.equal(process.env.FIRESTORE_EMULATOR_HOST,'127.0.0.1:18082');assert.equal(process.env.OUTBOX_CONSENT,'true');sdk.setLogLevel('silent');
const a=aa.initializeApp({projectId:'demo-push-stage1'},'sprint4-legacy-consent'),db=admin.getFirestore(a),c=apps.initializeApp({projectId:'demo-push-stage1',apiKey:'synthetic-only',appId:'synthetic-only'},'sprint4-legacy-client'),d=sdk.getFirestore(c);
sdk.connectFirestoreEmulator(d,'127.0.0.1',18082,{mockUserToken:{sub:'student_A',user_id:'student_A'}});
after(async()=>{await sdk.terminate(d);await apps.deleteApp(c);await db.terminate();await aa.deleteApp(a);});
test('unmodified current Main consent writer is '+(process.env.OUTBOX_TEST_MODE==='strict'?'atomically rejected by strict Rules':'preserved by transition Rules without an outbox'),async()=>{
 for(const[uid,role]of[['student_A','student'],['facilitator_A','facilitator'],['facilitator_B','facilitator']])await db.doc('users/'+uid).set({uid,role,isActive:true});
 await db.doc('facilitator_student_links/facilitator_A_student_A').set({studentId:'student_A',facilitatorId:'facilitator_A',status:'accepted'});
 await db.doc('conversations/thread_A').set({participantIds:['student_A','facilitator_A'],unreadCount:{facilitator_A:0}});
 const f=loadWriter('MAIN',sdk,d,{legacy:true}),send=()=>f.writer.sendMessage('thread_A','student_A','LEGACY_CONSENT_SYNTHETIC','student',undefined,'facilitator_A');
 if(process.env.OUTBOX_TEST_MODE==='strict'){
  await assert.rejects(send);assert.equal((await db.collection('messages').get()).size,0);assert.equal((await db.collection('notification_outbox').get()).size,0);assert.equal((await db.collection('student_identity_consents').get()).size,0);assert.equal((await db.doc('conversations/thread_A').get()).data().unreadCount.facilitator_A,0);
 }else{
  const id=await send();assert.equal((await db.doc('messages/'+id).get()).exists,true);assert.equal((await db.doc('notification_outbox/message_'+id).get()).exists,false);assert.equal((await db.doc('student_identity_consents/facilitator_A_student_A').get()).data().facilitatorId,'facilitator_A');assert.equal((await db.doc('conversations/thread_A').get()).data().unreadCount.facilitator_A,1);
 }
});
test('Main conversation creation requires the canonical accepted relationship and cannot retarget members',async()=>{
 const ref=sdk.doc(d,'conversations/authorized_new');await sdk.setDoc(ref,{participantIds:['student_A','facilitator_A'],unreadCount:{facilitator_A:0}});
 await assert.rejects(()=>sdk.setDoc(sdk.doc(d,'conversations/unauthorized_recipient'),{participantIds:['student_A','facilitator_B'],unreadCount:{facilitator_B:0}}));
 await assert.rejects(()=>sdk.updateDoc(ref,{participantIds:['student_A','facilitator_B']}));
 assert.deepEqual((await db.doc('conversations/authorized_new').get()).data().participantIds,['student_A','facilitator_A']);
 assert.equal((await db.doc('conversations/unauthorized_recipient').get()).exists,false);
});
