'use strict';
// Test-process guard only; no OS firewall or global networking changes.
const net=require('node:net'),connect=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){const a=Array.isArray(args[0])?args[0]:args;let o=a[0];if(typeof o==='number'||typeof o==='string')o={port:o,host:typeof a[1]==='string'?a[1]:'localhost'};if(!['127.0.0.1','localhost','::1'].includes(o?.host||'localhost')||![1,18082].includes(Number(o?.port))||o?.path)throw Error('Outbox tests blocked non-emulator network');return connect.apply(this,args);};
